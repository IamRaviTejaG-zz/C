#include<stdio.h>

void main()
{
	char c;
	printf("Enter character to see its ASCII code: ");
	scanf("%c", &c);
	printf("\n\n");
	printf("%d", c);
}
