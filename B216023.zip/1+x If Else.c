#include<stdio.h>

void main()
{
	int a,b,n,x;
	printf("Enter the value of n & x: ");
	scanf("%d\n%d", &n, &x);
	if (n==1)
	{
		printf(1+x);
	}
	
	else if (n==2)
	{
		printf(1+(x/n));
	}
	
	else if (n==3)
	{
		printf(1+(x^n));
	}
	
	else
	{
		printf(1+(x*n));
	}
}
