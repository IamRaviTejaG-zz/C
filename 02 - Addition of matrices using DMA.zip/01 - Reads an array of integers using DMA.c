#include<stdio.h>

main()
{
    int *x, i, n;
    printf("Enter the size: ");
    scanf("%d", &n);
    x = (int *)calloc(n, sizeof(int));
    for (i=0; i<n; i++)
    {
        scanf("%d", (x+i));
    }
    system("cls");
    for (i=n-1; i>=0; i--)
    {
        printf("%d\t", *(x+i));
    }
}
