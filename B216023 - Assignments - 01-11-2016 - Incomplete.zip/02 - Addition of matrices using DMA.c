#include<stdio.h>

main()
{
    int *a[10], *b[10], *c[10], i, j, r1, c1;
    printf("Enter size of array A & array B:");
    scanf("%d%d", &r1, &c1);
    for (i=0; i<r1; i++)
    {
        a[i] = (int *)calloc(c1, sizeof(int));
        b[i] = (int *)calloc(c1, sizeof(int));
        c[i] = (int *)calloc(c1, sizeof(int));
    }
    printf ("Enter array A:\n\n");
    for (i=0; i<r1; i++)
    {
        for (j=0; j<c1; j++)
        {
            scanf("%d", (*(a+i)+j));
        }
    }
    printf ("\n\nEnter array B:\n\n");
    for (i=0; i<r1; i++)
    {
        for (j=0; j<c1; j++)
        {
            scanf("%d", (*(b+i)+j));
        }
    }
    system("cls");
    for (i=0; i<r1; i++)
    {
        for (j=0; j<c1; j++)
        {
            *(*(c+i)+j) = *(*(a+i)+j) + *(*(b+i)+j);
        }
    }
    printf("Array C is as follows:\n\n");
    for (i=0; i<r1; i++)
    {
        for (j=0; j<c1; j++)
        {
            printf("%d\t", *(*(c+i)+j));
        }
        printf("\n");
    }
}
