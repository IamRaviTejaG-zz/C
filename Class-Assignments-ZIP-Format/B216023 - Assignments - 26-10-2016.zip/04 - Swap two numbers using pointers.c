#include<stdio.h>

main()
{
    int a, b, *x, *y, temp, c, d;
    printf("Enter the two numbers: \n\n");
    scanf("%d\t%d", &a, &b);
    system("cls");
    printf("Initially, numbers were:\n\n");
    printf("A: %d", a);
    printf("\nB: %d", b);
    x = &a;
    y = &b;
    temp = x;
    x = y;
    y = temp;
    c = *x;
    d = *y;
    printf("\n\n\nNow, numbers are:\n\n");
    printf("A: %d", c);
    printf("\nB: %d", d);
}
