#include<stdio.h>

struct a
{
    int a:7, b:5;
}x, y, z;

main()
{
    x.a = 12;
    x.b = 28;
    int f = 28;
    printf("%d\n%d", sizeof(x), sizeof(f));
}
