#include<stdio.h>

union student
{
    char name[50];
}std[50];

main()
{
    int a, b, i;
    printf("Enter number of students: ");
    scanf("%d", &a);
    for (i=0; i<a; i++)
    {
        printf("\nEnter student %d's name: ", i+1);
        scanf("%s", &std[i].name);
    }
    system("cls");
    printf("Enter the student number to see his name: ");
    scanf("%d", &b);
    printf("\n\nName: ");
    puts(std[b-1].name);
}
