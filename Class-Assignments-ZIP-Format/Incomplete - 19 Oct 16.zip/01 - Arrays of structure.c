#include<stdio.h>

struct student
{
    char name[50], branch[5], id[10];
}a = {"Ravi", "ETC", "B216023"};

func(struct student s)
{
    printf("%s\n%s\n%s", s.name, s.branch, s.id);
}

main()
{
    char c;
    printf("Enter 'A' or 'a' to view the structure: ");
    c = getchar();
    if (c == 'A' || c == 'a')
        func(a);
}
