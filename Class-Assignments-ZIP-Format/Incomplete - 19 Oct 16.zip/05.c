union bit_field
{
int rollno:5;
int age:3;
}a,b,c;
void main()
{


a.rollno=4;
b.age=32;
printf("b.age = %d SIZE OF a = %d SIZE of b = %d",b.age,sizeof(a),sizeof(b));

}
