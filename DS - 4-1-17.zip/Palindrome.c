#include<stdio.h>
#include<string.h>

int main()
{
    system("cls");
    int i, j, flag = 0, len = 0, mid = 0;
    char s[20];
    printf("Enter string: ");
    gets(s);
    len = strlen(s);
    if (len%2==0)
        mid = (len/2) + 1;
    else
        mid = (len-1) / 2;
    for (i=0, j=len-1; i<mid, j>=mid; i++, j--)
    {
        if (s[i]!=s[j])
            flag = 1;
        else
            flag = 0;
    }
    if (flag == 0)
        printf("\n\nPalindrome");
    else
        printf("\n\nNot Palindrome");
    return 0;
}
